package edu02.oop.domain;

/**
 * <pre>
 * TODO : Employee 도메인 클래스에 대한 테스트 클래스
 * - 직원 정보는 제공한 엑셀정보를 참고하세요.
 * 
 * EMPNO	EMPNAME	JOB	   		MGRNO	HIREDATE	SALARY	COMMISSION	DEPTNO
 * 7369		SMITH	CLERK		7902	1980-12-17	800					20
 * 7499		ALLEN	SALESMAN	7698	1981-02-20	1600	300			30
 * 7521		WARD	SALESMAN	7698	1981-02-22	1250	500			30
 * 7844		TURNER	SALESMAN	7698	1981-09-08	1500	0			30
 * </pre>
 * @author Administrator
 *
 */
public class EmployeeTest {
	
	public static void main(String[] args) {

	}

}
